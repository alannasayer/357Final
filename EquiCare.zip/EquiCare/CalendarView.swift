import SwiftUI
import UIKit
import FSCalendar

struct CalendarView: UIViewRepresentable {
    @Binding var selectedDate: Date
    var events: [HorseEvent]
    @Binding var selectedDays: Set<String>

    func makeUIView(context: Context) -> FSCalendar {
        let calendar = FSCalendar()
        calendar.delegate = context.coordinator
        calendar.dataSource = context.coordinator
        calendar.allowsMultipleSelection = true

        // Customizing the calendar appearance
        calendar.appearance.headerTitleColor = UIColor.systemBlue
        calendar.appearance.weekdayTextColor = UIColor.systemBlue
        calendar.appearance.todayColor = UIColor.systemBlue
        calendar.appearance.selectionColor = UIColor.systemPink
        calendar.appearance.eventDefaultColor = UIColor.systemOrange
        calendar.appearance.eventSelectionColor = UIColor.systemGreen

        return calendar
    }

    func updateUIView(_ uiView: FSCalendar, context: Context) {
        uiView.reloadData()

        for day in selectedDays {
            if let date = CalendarView.dateFormatter.date(from: day) {
                uiView.select(date)
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, FSCalendarDelegate, FSCalendarDataSource {
        var parent: CalendarView

        init(_ parent: CalendarView) {
            self.parent = parent
        }

        func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
            return parent.events.filter { Calendar.current.isDate($0.date, inSameDayAs: date) }.count
        }

        func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
            let day = CalendarView.dateFormatter.string(from: date)
            if parent.selectedDays.contains(day) {
                parent.selectedDays.remove(day)
            } else {
                parent.selectedDays.insert(day)
            }
            parent.selectedDate = date
        }

        func calendar(_ calendar: FSCalendar, didDeselect date: Date, at monthPosition: FSCalendarMonthPosition) {
            let day = CalendarView.dateFormatter.string(from: date)
            parent.selectedDays.remove(day)
        }
    }

    static var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }
}

