import Foundation
import Combine
import SwiftUI

class EventManager: ObservableObject {
    static let shared = EventManager()  // Singleton instance to be accessed globally

    @Published var events: [HorseEvent] = []  // Use @Published to notify views of changes
    @Published var trainerEvents: [TrainerEvent] = []  // Use @Published for trainer events

    private init() {}  // Private initializer to enforce singleton usage

    // Adds an event to the list
    func addEvent(horseName: String, date: Date, type: EventType, notes: String? = nil) {
        let newEvent = HorseEvent(horseName: horseName, date: date, eventType: type, notes: notes)
        DispatchQueue.main.async {
            self.events.append(newEvent)
            self.events.sort { $0.date < $1.date } // Optionally, keep events sorted by date
        }
    }

    // Adds a trainer event to the list
    func addTrainerEvent(trainerName: String, date: Date, workingHours: String, color: Color) {
        let newEvent = TrainerEvent(trainerName: trainerName, date: date, workingHours: workingHours, color: color)
        DispatchQueue.main.async {
            self.trainerEvents.append(newEvent)
            self.trainerEvents.sort { $0.date < $1.date } // Optionally, keep events sorted by date
        }
    }

    // Removes an event by its unique identifier
    func removeEvent(_ event: HorseEvent) {
        DispatchQueue.main.async {
            self.events.removeAll { $0.id == event.id }
        }
    }

    // Returns a list of events for a specific date
    func events(for date: Date) -> [HorseEvent] {
        events.filter { Calendar.current.isDate($0.date, inSameDayAs: date) }
    }

    // Returns a list of trainer events for a specific date
    func trainerEvents(for date: Date) -> [TrainerEvent] {
        trainerEvents.filter { Calendar.current.isDate($0.date, inSameDayAs: date) }
    }
}

struct TrainerEvent: Identifiable {
    let id = UUID()
    var trainerName: String
    var date: Date
    var workingHours: String
    var color: Color
}

