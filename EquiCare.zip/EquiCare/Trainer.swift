//
//  Trainer.swift
//  EquiCare
//
//  Created by Alanna Sayer on 5/16/24.
//


import Foundation
import SwiftUI

struct Trainer: Identifiable {
    var id = UUID()
    var name: String
    var workingDays: [String: TrainerShift]  // Dictionary to hold days and shift details
}

struct TrainerShift {
    var hours: String
    var color: Color
}

