import SwiftUI

struct MainCalendarView: View {
    @EnvironmentObject var eventManager: EventManager
    @State private var selectedDate = Date()

    var body: some View {
        VStack {
            CalendarView(selectedDate: $selectedDate, events: eventManager.events, selectedDays: .constant(Set(eventManager.trainerEvents.map { CalendarView.dateFormatter.string(from: $0.date) })))
                .frame(height: 300)

            List {
                ForEach(eventManager.events(for: selectedDate), id: \.id) { event in
                    VStack(alignment: .leading) {
                        Text(event.horseName)
                        Text(event.eventType.rawValue)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        Text(event.notes ?? "No additional notes")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                ForEach(eventManager.trainerEvents(for: selectedDate), id: \.id) { event in
                    VStack(alignment: .leading) {
                        Text(event.trainerName)
                            .foregroundColor(event.color)
                        Text(event.workingHours)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                }
            }
        }
    }
}

struct MainCalendarView_Previews: PreviewProvider {
    static var previews: some View {
        MainCalendarView().environmentObject(EventManager.shared)
    }
}

