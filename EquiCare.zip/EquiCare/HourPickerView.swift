//
//  HourPickerView.swift
//  EquiCare
//
//  Created by Alanna Sayer on 5/16/24.
//

import SwiftUI

struct HourPickerView: View {
    @Binding var selectedDays: Set<String>
    @Binding var workingHours: String
    @Binding var trainer: Trainer
    @Binding var selectedDate: Date
    @Binding var selectedColor: Color

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Working Hours")) {
                    TextField("Enter working hours (e.g., 9 AM - 5 PM)", text: $workingHours)
                }
                Button("Save Hours") {
                    saveHours()
                }
                .padding()
            }
            .navigationTitle("Set Working Hours")
        }
        .onAppear {
            let day = CalendarView.dateFormatter.string(from: selectedDate)
            if let shift = trainer.workingDays[day] {
                workingHours = shift.hours
                selectedColor = shift.color
            } else {
                workingHours = ""
                selectedColor = .pink
            }
        }
    }

    private func saveHours() {
        let day = CalendarView.dateFormatter.string(from: selectedDate)
        trainer.workingDays[day] = TrainerShift(hours: workingHours, color: selectedColor)
        selectedDays.insert(day)
    }
}

struct HourPickerView_Previews: PreviewProvider {
    static var previews: some View {
        HourPickerView(selectedDays: .constant(["2023-05-16"]), workingHours: .constant("9 AM - 5 PM"), trainer: .constant(Trainer(name: "John Doe", workingDays: [:])), selectedDate: .constant(Date()), selectedColor: .constant(.pink))
    }
}
