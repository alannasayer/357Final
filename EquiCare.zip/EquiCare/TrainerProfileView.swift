import SwiftUI

struct TrainerProfileView: View {
    @State private var trainerName = ""
    @State private var selectedColor: Color = .pink
    @State private var trainer = Trainer(name: "", workingDays: [:])
    @State private var selectedDays = Set<String>()
    @State private var workingHours = ""
    @State private var showingHourPicker = false
    @State private var selectedDate = Date()
    @State private var showingSaveConfirmation = false
    @EnvironmentObject var eventManager: EventManager

    let colors: [Color] = [.pink, .blue, .green, .orange, .purple]

    var body: some View {
        VStack {
            Text("Welcome trainers!")
                .font(.largeTitle)
                .padding()

            TextField("Enter your name and hours working", text: $trainerName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            Text("Select Shift Color")
                .font(.headline)
                .padding()

            HStack {
                ForEach(colors, id: \.self) { color in
                    Circle()
                        .fill(color)
                        .frame(width: 30, height: 30)
                        .onTapGesture {
                            selectedColor = color
                        }
                        .overlay(
                            Circle()
                                .stroke(Color.black, lineWidth: selectedColor == color ? 2 : 0)
                        )
                }
            }
            .padding()

            CalendarView(selectedDate: $selectedDate, events: [], selectedDays: $selectedDays)
                .frame(height: 300)

            List {
                ForEach(Array(selectedDays), id: \.self) { day in
                    HStack {
                        Text(day)
                        Spacer()
                        Text(trainer.workingDays[day]?.hours ?? "Input Hours")
                            .foregroundColor(.gray)
                            .onTapGesture {
                                selectedDate = CalendarView.dateFormatter.date(from: day) ?? Date()
                                if let shift = trainer.workingDays[day] {
                                    workingHours = shift.hours
                                    selectedColor = shift.color
                                } else {
                                    workingHours = ""
                                    selectedColor = .pink
                                }
                                showingHourPicker = true
                            }
                    }
                }
            }

            Button("Save Profile") {
                saveProfile()
                showingSaveConfirmation = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    showingSaveConfirmation = false
                }
            }
            .padding()
            .sheet(isPresented: $showingHourPicker) {
                HourPickerView(selectedDays: $selectedDays, workingHours: $workingHours, trainer: $trainer, selectedDate: $selectedDate, selectedColor: $selectedColor)
            }

            if showingSaveConfirmation {
                Text("Saved Successfully")
                    .font(.headline)
                    .foregroundColor(.green)
                    .padding()
            }
        }
        .navigationTitle("Trainer Profile")
    }

    private func saveProfile() {
        for day in selectedDays {
            if let date = CalendarView.dateFormatter.date(from: day) {
                eventManager.addTrainerEvent(trainerName: trainerName, date: date, workingHours: workingHours, color: selectedColor)
                trainer.workingDays[day] = TrainerShift(hours: workingHours, color: selectedColor)
            }
        }
    }

    private func saveHours() {
        let day = CalendarView.dateFormatter.string(from: selectedDate)
        trainer.workingDays[day] = TrainerShift(hours: workingHours, color: selectedColor)
        selectedDays.insert(day)
    }
}

struct TrainerProfileView_Previews: PreviewProvider {
    static var previews: some View {
        TrainerProfileView().environmentObject(EventManager.shared)
    }
}

