//
//  HorseEvent.swift
//  EquiCare
//
//  Created by Alanna Sayer on 5/8/24.
//


// HorseEvent.swift
import Foundation

struct HorseEvent: Identifiable {
    let id = UUID()
    var horseName: String
    var date: Date
    var eventType: EventType
    var notes: String?
}

enum EventType: String, CaseIterable {
    case exercise = "Exercise"
    case hoofCare = "Hoof Care"
    case teethFloating = "Teeth Floating"
    case other = "Other"
}
