import SwiftUI
import PhotosUI

struct AddHorseView: View {
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var eventManager: EventManager
    @Binding var horses: [Horse]

    @State private var horseName = ""
    @State private var lastRiddenDate = Date()
    @State private var exerciseDuration = 5.0
    @State private var nextHoofCareDate = Date()
    @State private var nextTeethFloatingDate = Date()
    @State private var needsMedicine = false
    @State private var medicineName = ""
    @State private var tackUsed = ""
    @State private var lastRider = ""
    @State private var behaviorRating = 3.0
    @State private var feelingRating = 3.0
    @State private var previousInjuries = ""
    @State private var image: UIImage?

    @State private var showImagePicker = false

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Horse Information")) {
                    TextField("Horse Name", text: $horseName)
                    DatePicker("Last Ridden", selection: $lastRiddenDate, displayedComponents: .date)
                    VStack {
                        Text("Exercise Duration: \(Int(exerciseDuration)) minutes")
                        Slider(value: $exerciseDuration, in: 5...90, step: 1)
                    }
                }
                Section(header: Text("Scheduled Care")) {
                    DatePicker("Next Hoof Care", selection: $nextHoofCareDate, displayedComponents: .date)
                    DatePicker("Next Teeth Floating", selection: $nextTeethFloatingDate, displayedComponents: .date)
                }
                Section(header: Text("Medical and Behavioral Info")) {
                    Toggle("Needs Medicine", isOn: $needsMedicine)
                    if needsMedicine {
                        TextField("Medicine Name", text: $medicineName)
                    }
                    TextField("Tack Used", text: $tackUsed)
                    TextField("Last Rider", text: $lastRider)
                    VStack {
                        Text("Behavior Rating: \(Int(behaviorRating))")
                        Slider(value: $behaviorRating, in: 1...5, step: 1)
                    }
                    VStack {
                        Text("Soundness Rating: \(Int(feelingRating))")
                        Slider(value: $feelingRating, in: 1...5, step: 1)
                    }
                    TextField("Previous Injuries", text: $previousInjuries)
                }
                Section(header: Text("Horse Image")) {
                    if let image = image {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                    }
                    Button("Select Image") {
                        showImagePicker = true
                    }
                }
                Button(action: saveHorseDetails) {
                    Text("Save")
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                }
            }
            .navigationTitle("Add Horse")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(image: $image)
            }
        }
    }

    private func saveHorseDetails() {
        let newHorse = Horse(
            name: horseName,
            lastRiddenDate: lastRiddenDate,
            exerciseDuration: exerciseDuration,
            nextHoofCareDate: nextHoofCareDate,
            nextTeethFloatingDate: nextTeethFloatingDate,
            needsMedicine: needsMedicine,
            medicineName: medicineName,
            tackUsed: tackUsed,
            lastRider: lastRider,
            behaviorRating: behaviorRating,
            feelingRating: feelingRating,
            previousInjuries: previousInjuries.isEmpty ? [] : previousInjuries.components(separatedBy: ", "),
            image: image
        )
        horses.append(newHorse)
        eventManager.addEvent(horseName: horseName, date: nextHoofCareDate, type: .hoofCare, notes: "Hoof care for \(horseName)")
        eventManager.addEvent(horseName: horseName, date: nextTeethFloatingDate, type: .teethFloating, notes: "Teeth floating for \(horseName)")
        dismiss()
    }
}

struct AddHorseView_Previews: PreviewProvider {
    static var previews: some View {
        AddHorseView(horses: .constant([])).environmentObject(EventManager.shared)
    }
}

