import SwiftUI

struct ContentView: View {
    @State private var horses = [Horse]()
    @State private var showingAddHorseView = false
    @State private var showCalendar = false

    var body: some View {
        NavigationView {
            VStack {
                // Display a centered welcome message with custom font
                Text("Welcome to EquiCare!\nThe app for all things equestrian.")
                    .font(.system(size: 24, weight: .bold, design: .serif))  // Use a custom font
                    .multilineTextAlignment(.center)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)

                List(horses, id: \.id) { horse in
                    NavigationLink(destination: HorseDetailView(horse: horse)) {
                        HStack {
                            VStack(alignment: .leading) {
                                Text(horse.name)
                                    .font(.headline)
                                Text("Last Ridden: \(horse.lastRiddenDate, style: .date)")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }
                .listStyle(PlainListStyle())

                Spacer()

                HStack {
                    Button(action: {
                        showCalendar = true
                    }) {
                        HStack {
                            Image(systemName: "calendar")
                            Text("Show Calendar")
                        }
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.blue)
                        .cornerRadius(10)
                    }
                    .padding()

                    Button(action: {
                        showingAddHorseView = true
                    }) {
                        HStack {
                            Image(systemName: "plus")
                            Text("Add Horse")
                        }
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.green)
                        .cornerRadius(10)
                    }
                    .padding()
                }

                NavigationLink(destination: TrainerProfileView()) {
                    Text("Go to Trainer Profile")
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.pink)
                        .cornerRadius(10)
                }
                .padding()
            }
            .background(Color(.systemGray6))  // Set the background color to light grey
            .navigationTitle("EquiCare")
            .sheet(isPresented: $showCalendar) {
                MainCalendarView()
            }
            .sheet(isPresented: $showingAddHorseView) {
                AddHorseView(horses: $horses)
            }
        }
        .background(Color(.systemGray6))  // Set the background color to light grey
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(EventManager.shared)
    }
}

