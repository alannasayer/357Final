import SwiftUI

struct HorseDetailView: View {
    var horse: Horse

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                if let image = horse.image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                
                Form {
                    Section(header: Text("General Information")) {
                        Text("Name: \(horse.name)")
                        Text("Last Ridden: \(horse.lastRiddenDate, style: .date)")
                    }
                    Section(header: Text("Medical and Care")) {
                        if horse.needsMedicine {
                            Text("Medicine: \(horse.medicineName)")
                        }
                        Text("Next Hoof Care: \(horse.nextHoofCareDate, style: .date)")
                    }
                }
            }
            .padding()
        }
        .navigationTitle(horse.name)
    }
}

struct HorseDetailView_Previews: PreviewProvider {
    static var previews: some View {
        HorseDetailView(horse: Horse(
            name: "Sample Horse",
            lastRiddenDate: Date(),
            exerciseDuration: 30,
            nextHoofCareDate: Date(),
            nextTeethFloatingDate: Date(),
            needsMedicine: false,
            medicineName: "",
            tackUsed: "",
            lastRider: "",
            behaviorRating: 4,
            feelingRating: 4,
            previousInjuries: [],
            image: UIImage(systemName: "photo") // Sample image
        ))
    }
}

