import SwiftUI

@main
struct EquiCareApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(EventManager.shared)
        }
    }
}

