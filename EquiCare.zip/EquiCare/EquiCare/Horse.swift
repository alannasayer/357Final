import Foundation
import UIKit

struct Horse: Identifiable {
    var id = UUID()
    var name: String
    var lastRiddenDate: Date
    var exerciseDuration: Double
    var nextHoofCareDate: Date
    var nextTeethFloatingDate: Date
    var needsMedicine: Bool
    var medicineName: String
    var tackUsed: String
    var lastRider: String
    var behaviorRating: Double
    var feelingRating: Double
    var previousInjuries: [String]
    var image: UIImage?  // Add this line
}

