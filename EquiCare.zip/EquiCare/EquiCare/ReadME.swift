//
//  ReadME.swift
//  EquiCare
//
//  Created by Alanna Sayer on 5/17/24.
// Alanna Sayer Readme
// 2410416
// asayer@chapman.edu
// 17 May 2024



